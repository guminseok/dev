import { React , useState } from 'react';
// import Daily from '../subPopular/Daily';
// import Weeks from '../subPopular/Weeks';
// import Months from '../subPopular/Months';

    const CryptographicAsset = (props) => {

       // const [ViewSubTitle, setViewSubTitle] = useState(<Daily/>);
        const [tab, setTab] = useState('prev');
        return (
            <div className="font">

            <div><h1>CryptographicAsset</h1></div>
                      <div className = "PopularTitle">
                      {/* <span className="font2" onClick={() => setViewSubTitle(<Daily/>,'curr')}> デイリー</span>
                      <span className={`-btn ${tab === 'prev' ? 'active' : ''}`} onClick={() => setViewSubTitle(<Weeks/>)}> 週間</span>
                      <span className="font2" onClick={() => setViewSubTitle(<Months/>)}> 月間</span>  */}
                    </div>
                    CryptographicAsset
                      <hr/>
                  {/* //  { ViewSubTitle } */}
             </div>
                    
                    
       );
}
    
    export default CryptographicAsset
    