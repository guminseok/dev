import React from 'react'

function Header () {
      return(
        <header className='header'>
            <div className='grid grid-cols-4 gap-4'>
              <div className='iconLayout'>
                
                  <a target='_blank' href='https://vwcity.net/' >
                     <img src='/icon/home_icon.png' className='iconImg' alt='React' /> ホーム 
                  </a>
                  <a target='_blank' href='https://vwcity.net/tenants' >
                     <img src='/icon/street_icon.png' className='iconImg' alt='React' /> 金融街
                  </a>
                  <a target='_blank' href='https://vwcity.net/bulletin_boards'>
                     <img src='/icon/board_icon.png' className='iconImg' alt='React' /> コミュニティ
                  </a> 
             {/* <Link href='/'>  */}
                  <img src='/icon/library_icon.png' className='iconImg' alt='React' /> Library
             {/* </Link> */}
              </div>
          
          {/* <Link to='/company' className='header_menu_icon'> 
           <img src={street} className='App-logo' alt='React' />  
            <div className='aa'> aaaa</div>
          </Link> */}
          {/* <Link to='/company' className='header_menu_icon'> 
            <img src={board} className='App-logo' alt='React' />
          </Link>
          <Link to='/company' className='header_menu_icon'> 
            <img src={library} className='App-logo' alt='React' />
          </Link>
          <Link to='/company' className='header_menu_icon'> 
            <img src={login} className='App-logo' alt='React' />
          </Link>*/}
          </div> 
        </header>
      );
}
 

  export default Header
