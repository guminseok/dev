import React, { useState } from 'react';
import Top from  './title/top'
import Popular from './title/popular'
import AttentionInvestment from './title/attentionInvestment'
import Investment from './title/investment'
import Blockchain from './title/blockchain'
import AccountOpen from './subTitle/accountOpen'
import VirtualCurrency from './subTitle/virtualCurrency'
import CryptographicAsset from './subTitle/cryptographicAsset'
import SmartContract from './subTitle/smartContract'
import SubBlockchain from './subTitle/subBlockchain'
import Metavers from './subTitle/metavers'

function Main () {
       const [ViewSubTitle, setViewSubTitle] = useState(<Top/>)
      return(
        <div className='top-body'>
        <div  className='main'>
        <div class="grid grid-cols-6 gap-4">
          <div class="col-start-2 col-span-4 top-menu ...">
          <div class="top ..."></div>
          <div className = 'titleItem'>
            <div className='titleList' onClick={() => setViewSubTitle(<Top/>)}>トップ</div>
            <div className='titleList' onClick={() => setViewSubTitle(<Popular/>)}> ランキング</div>
            <div className='titleList' onClick={() => setViewSubTitle(<AttentionInvestment/>)}> 注目の投資</div>
            <div className='titleList' onClick={() => setViewSubTitle(<Investment/>)}> 投資の基本</div>
            <div className='titleList' onClick={() => setViewSubTitle(<Blockchain/>)}> ブロックチェーン</div> 
          </div>
          <div className = 'keyWordItem'>
            <div className = 'keyWordTitle'>注目のキーワード</div>
            <div>
            <span className = 'keyWord' onClick={() => setViewSubTitle(<VirtualCurrency/>)}> #仮想通貨</span>  
            <span className = 'keyWord' onClick={() => setViewSubTitle(<CryptographicAsset/>)}> #暗号資産</span>  
            <span className = 'keyWord' onClick={() => setViewSubTitle(<AccountOpen />)}> #口座開設</span>  
            <span className = 'keyWord' onClick={() => setViewSubTitle(<SmartContract/>)}> #スマートコントラクト</span>  
            <span className = 'keyWord' onClick={() => setViewSubTitle(<SubBlockchain/>)}> #ブロックチェーン</span>  
            <span className = 'keyWord' onClick={() => setViewSubTitle(<Metavers/>)}> #メタバース</span>  
            </div>
            </div>
            <hr/>
            {ViewSubTitle}
          </div>
          </div>
        </div>
        </div>
      );
    }
 

  export default Main
