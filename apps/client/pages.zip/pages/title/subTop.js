// import { Swiper, SwiperSlide } from 'swiper/react';
// import './subTop.module.scss';
import style from './subTop.module.scss';

export default () => {
  return (
    <div className = 'mainSub'>
    <div className = 'mainSubTitle'>新着記事</div>
      <div className = 'mainSubImg'>
        <div className = 'mainSubList'>
          <div>
          {/* className = 'main-sub-context'  이거 사용 안하고 있음 삭제해야함 */}
          <img src='/mainSub/image1.png' className='main-img' alt='React' /> 
          <div className = 'main-sub-context'>
          新NISAの登場で一般NISAからのロールオーバーが可能に！
          </div>
          <div className={style['main-sub-line']}>
            <span className='main-sub-new'>NEW
            </span>
            <span className='main-sub-date'>2022/9/8
            </span>
            <hr className='main-sub-line'/>
            <div  className = 'main-sub-keyWord' >
          <span className = 'keyWord' > #仮想通貨</span>  
          <span className = 'keyWord' > #暗号資産</span>  
          </div>
          </div>
       
          </div>
        
        </div>

        <div className = 'mainSubList'>
          <img src='/mainSub/image2.png'className='main-img' alt='React' /> 
          <div>
          NFTの安全対策とは？乗っ取りやハッキング攻撃を徹底的に防ぐ！
          </div>
          <div className={style['main-sub-line']}>
            {/* <span className={style['.main-sub-new']}>NEW */}
            <span className='main-sub-new'>NEW
            </span>
            <span className='main-sub-date'>2022/9/8
            </span>
            <hr className='main-sub-line'/>
            <div  className = 'main-sub-keyWord' >
          <span className = 'keyWord' > #仮想通貨</span>  
          <span className = 'keyWord' > #暗号資産</span>  
          </div>
          </div>
          </div>
        </div>

      <div className = 'mainSubImg'>
        <div className = 'mainSubList'>
          <img src='/mainSub/image3.png' className='main-img' alt='React' /> 
          <div className = 'main-sub-context'>
          太陽光発電ファンドと不特法の関係：第1回「適用される状況」
          </div>
          <div className={style['main-sub-line']}>
            <span className='main-sub-new'>NEW
            </span>
            <span className='main-sub-date'>2022/9/8
            </span> 
            <hr className='main-sub-line'/>
            <div  className = 'main-sub-keyWord' >
          <span className = 'keyWord' > #仮想通貨</span>  
          <span className = 'keyWord' > #暗号資産</span>  
          </div>
          </div>
        </div>

        <div className = 'mainSubList'>
          <img src='/mainSub/image4.png'className='main-img' alt='React' /> 
          <div className = 'main-sub-context'>
          NFTの乗っ取り被害が急増中！？簡単・効果的な4つの安全対策とは 
          </div>
          <div className={style['main-sub-line']}>
            <span className='main-sub-new'>NEW
            </span>
            <span className='main-sub-date'>2022/9/8
            </span>
            
            <hr className='main-sub-line'/>
            <div  className = 'main-sub-keyWord' >
          <span className = 'keyWord' > #仮想通貨</span>  
          <span className = 'keyWord' > #暗号資産</span>  
          </div>
          </div>
          </div>
        </div>

      <div className = 'mainSubImg'>
        <div className = 'mainSubList'>
          <img src='/mainSub/image5.png' className='main-img' alt='React' /> 
          <div className = 'main-sub-context'>
          NFT×自動車の多彩な可能性。アート、証明書、コレクションに
          </div>
          <div className={style['main-sub-line']}>
            <span className='main-sub-new'>NEW
            </span>
            <span className='main-sub-date'>2022/9/8
            </span>
         
          <hr className='main-sub-line'/>
            <div  className = 'main-sub-keyWord' >
          <span className = 'keyWord' > #仮想通貨</span>  
          <span className = 'keyWord' > #暗号資産</span>  
          </div>
          </div>
        </div>
        
        <div className = 'mainSubList'>
          <img src='/mainSub/image6.png'className='main-img' alt='React' /> 
          <div className = 'main-sub-context'>
          ETFと投資信託の違いは？それぞれの特徴を比較
          </div>
          <div className={style['main-sub-line']}>
            <span className='main-sub-new'>NEW
            </span>
            <span className='main-sub-date'>2022/9/8
            </span>
            <hr className='main-sub-line'/>
            <div  className = 'main-sub-keyWord' >
          <span className = 'keyWord' > #仮想通貨</span>  
          <span className = 'keyWord' > #暗号資産</span>  
          </div>
          </div>
          </div>
        </div>

        <div>
          <button className={style['main-sub-button']}> 記事一覧</button>
        </div>

        <hr className = 'Line'/>
        </div>
  );
};