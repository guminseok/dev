import style from './subTop.module.scss';

export default () => {
  return (
    <div >
    <div className = 'mainSub mainSubTitle'>特集記事</div>
      <div className={style['main-sub-feature-title']}> 
        NFT×自動車の多彩な可能性。アート、証明書、コレクションに
      </div>
      <div className={style['main-sub-feature-content']}> 
       <img src='feature/feature.png' className={style['main-sub-feature-img']} alt='React' />
       <span className={style['main-sub-feature-text']}>太陽光発電ファンドに不特法は適用されるのでしょうか？太陽光発電事業を目的として、宅地や建物を購入するケースは少なくありません。太陽光発電が目的となる不動産から収益を得て、投資家に…</span>
      </div>

      <div className={style['main-sub-feature-title']}> 
        ETFと投資信託の違いは？それぞれの特徴を比較
      </div>
      <div className={style['main-sub-feature-content']}> 
       <img src='feature/feature2.png' className={style['main-sub-feature-img']} alt='React' />
       <span className={style['main-sub-feature-text']}>
       初心者向けの投資として、ETFや投資信託があります。どちらも分配益が期待できる金融商品です。本記事では、ETFと投資信託の特徴を比較して違いを解説します。
       ETFは、Exchange Traded Funds…
       </span>
      </div>

      <div className={style['main-sub-feature-title']}> 
        不動産投資信託（リート）とは？仕組みやメリット・デメリットを解説
      </div>
      <div className={style['main-sub-feature-content']}> 
       <img src='feature/feature3.png' className={style['main-sub-feature-img']} alt='React' />
       <span className={style['main-sub-feature-text']}>
         米Facebook社のMetaへの変更以降、一層注目が高まっているメタバース。リアルな世界と同様に経済活動をメタバースの世界でも繰り広げようと、世界中のお金が集まってきています。経済を…
       </span>
      </div>
      <div className = 'mainSub'>
      <button className={style['main-sub-button']}> 特集記事一覧 </button>
      </div>
    </div>
  );
};