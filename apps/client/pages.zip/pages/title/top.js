// import { Swiper, SwiperSlide } from 'swiper/react';
import SubTop from  './subTop'
import SubTopVideo from  './subTopVideo'
import SubTopFeature from  './subTopFeature'

export default () => {
  return (
    <div className = 'main'>
      {/* <SwiperSlide>
        <img src="https://placehold.jp/3d4070/ffffff/700x450.png?text=1" alt="1" />
      </SwiperSlide>
      <SwiperSlide>
        <img src="https://placehold.jp/3d4070/ffffff/700x450.png?text=2" alt="2" />
      </SwiperSlide>
      <SwiperSlide>
        <img src="https://placehold.jp/3d4070/ffffff/700x450.png?text=3" alt="3" />
      </SwiperSlide>
      <SwiperSlide>
        <img src="https://placehold.jp/3d4070/ffffff/700x450.png?text=4" alt="4" />
      </SwiperSlide> */}
      <div className = 'mainFont'>
        {/* <img src={test} class="col-start-2 col-span-4 ..." alt='React' onClick={() => setViewSubTitle(<AttentionInvestment/>)}/> */}
        <div className = 'mainLeftRight'>
          <img src='/left.png' class="left" alt='React' /> 
        </div>
        <div className = 'mainImg'>
          <div>
          <img src='/top.png' class="naka" alt='React' /> 
          </div>
          <div className = 'mainFontSize'>
            新NISAの登場で一般NISAからのロールオーバーが可能に！詳しく解説
          </div>
          <hr className = 'Line'/>
          <span className = 'keyWord' > #仮想通貨</span>  
          <span className = 'keyWord' > #暗号資産</span>  
        </div>
        <div className = 'mainLeftRight'>
          <img src='/right.png' class="right" alt='React' /> 
        </div> 
      </div> 
        
        <SubTop/>
        <SubTopVideo/>
        <SubTopFeature/>
          
     </div>
  );
};