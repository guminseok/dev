import style from './subTop.module.scss';

export default () => {
  return (
    <div className = 'mainSub'>
    <div className = 'mainSubTitle'>ピックアップ動画 </div>
    {/* <video src="https://www.youtube.com/watch?v=TlsGflZVIec"/> */}
       <img src='/video.png' className='main-img' alt='React' /> 
          <div className = 'main-sub-context'>
          ETFと投資信託の違いは？それぞれの特徴を比較
          </div>
          <div className={style['main-sub-line']}>
            <span className='main-sub-new'>NEW
            </span>
            <span className='main-sub-date'>2022/9/8
            </span>
            <hr className='main-sub-line'/>
            <div  className = 'main-sub-keyWord' >
          <span className = 'keyWord' > #仮想通貨</span>  
          <span className = 'keyWord' > #暗号資産</span>  
          </div>
          </div>
          <button className={style['main-sub-button']}> 動画一覧</button>

        <hr className = 'Line'/>
          </div>
  );
};