import { React , useState } from 'react';
// import Daily from '../subPopular/Daily';
// import Weeks from '../subPopular/Weeks';
// import Months from '../subPopular/Months';

    const AttentionInvestment = (props) => {

       // const [ViewSubTitle, setViewSubTitle] = useState(<Daily/>);
        const [tab, setTab] = useState('prev');
        return (
            <div className="font">

            <div><h1>AttentionInvestment</h1></div>
                      <div className = "PopularTitle">
                      {/* <span className="font2" onClick={() => setViewSubTitle(<Daily/>,'curr')}> デイリー</span>
                      <span className={`-btn ${tab === 'prev' ? 'active' : ''}`} onClick={() => setViewSubTitle(<Weeks/>)}> 週間</span>
                      <span className="font2" onClick={() => setViewSubTitle(<Months/>)}> 月間</span>  */}
                    </div>
                    AttentionInvestment
                      <hr/>
                  {/* //  { ViewSubTitle } */}
             </div>
                    
                    
       );
}
    
    export default AttentionInvestment
    